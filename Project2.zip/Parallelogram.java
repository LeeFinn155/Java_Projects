import java.awt.geom.Point2D;

public class Parallelogram extends Trapezoid {
	private double area;

	// Getters
	public double getWidth() {
		return width;
	}

	public double getArea() {
		return area;
	}

	// Setters
	public void setArea(double area) {
		this.area = area;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public Parallelogram() {
	}

	private double width;

	public Parallelogram(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
		super(x1, y1, x2, y2, x3, y3, x4, y4);
		setWidth((Point2D.distance(x3, y3, x4, y4)));
		setArea((getWidth() * getHeight()));
	}

	@Override
	public String toString() {
		return

		"Parallelagram:" + "\n" + "Point 1 = " + getPoint1() + "\n" + "Point 2 = " + getPoint2() + "\n" + "Point 3 = "
				+ getPoint3() + "\n" + "Point 4 = " + getPoint4() + "\n" + "Width = " + getWidth() + "\n" + "Height = "
				+ getHeight() + "\n" + "Area = " + getArea() + "\n";
	}
}
