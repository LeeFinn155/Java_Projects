
public class Point {
	private double y;
	private double x;

	public Point() {
	}

	public Point(double x, double y) {
		setX(x);
		setY(y);
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public String toString() {
		return "(" + getX() + "," + getY() + ")";
	}

	public static void main(double x, double y) {
		Point p = new Point(x, y);
		p.toString();
	}
}
