import java.awt.geom.Point2D;

public class Quadrilateral {
	private Point Point1;
	private Point Point2;
	private Point Point3;
	private Point Point4;
	private double side1;
	private double side3;
	private double height;
	private double area;

	
//Corner Getters
	public Point getPoint1() {
		return Point1;
	}

	public Point getPoint3() {
		return Point3;
	}

	public Point getPoint2() {
		return Point2;
	}

	public Point getPoint4() {
		return Point4;
	}
public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	//Corner Setters
	public void setPoint4(Point point4) {
		Point4 = point4;
	}

	public void setPoint2(Point point2) {
		Point2 = point2;
	}

	public void setPoint3(Point point3) {
		Point3 = point3;
	}

	public void setPoint1(Point point1) {
		Point1 = point1;
	}
//Calculation setters
	
	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	
	

	public Quadrilateral() {
	}

	public Quadrilateral(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
		setPoint1(new Point(x1, y1));
		setPoint2(new Point(x2, y2));
		setPoint3(new Point(x3, y3));
		setPoint4(new Point(x4, y4));
		pointsAndPerimeter(x1, y1, x2, y2, x3, y3, x4, y4);
	}

	public void pointsAndPerimeter(double x1, double y1, double x2, double y2, double x3, double y3, double x4,
			double y4) {
		side1 = Point2D.distance(x1, y1, x2, y2);
		side3 = Point2D.distance(x3, y3, x4, y4);
		setHeight((y1-y4));
		setArea((height * .5) * (side1 + side3));
	}


	public String toString() {
		return

		"Quadrilateral:" + "\n" + "Point 1 = " + getPoint1() + "\n" + "Point 2 = " + getPoint2() + "\n" + "Point 3 = "
				+ getPoint3() + "\n" + "Point 4 = "
				+ getPoint4() + "\n";
	}

}
