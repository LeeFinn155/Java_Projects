
public class Rectangle extends Parallelogram {

	public Rectangle() {
	}

	public Rectangle(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
		super(x1, y1, x2, y2, x3, y3, x4, y4);
	}

	@Override
	public String toString() {
		return

		"Rectangle:" + "\n" + "Point 1 = " + getPoint1() + "\n" + "Point 2 = " + getPoint2() + "\n" + "Point 3 = "
				+ getPoint3() + "\n" + "Point 4 = " + getPoint4() + "\n" + "Width = " + getWidth() + "\n" + "Height = "
				+ getHeight() + "\n" + "Area = " + getArea() + "\n";
	}
}
