/*  COS 161 USM, FALL 2018
 * Professor: Phoulady
 * Project:   Program 3
 * Date:	  11/8/2018
 * Author:	  Omar Gonzaga 
 */
// Employee abstract superclass implements Payable.

public abstract class Employee implements Payable {
	private String firstName;
	private String lastName;
	private String socialSecurityNumber;

	// three-argument constructor
	public Employee(String first, String last, String ssn) {
		firstName = first;
		lastName = last;
		socialSecurityNumber = ssn;
	}

	// set first name
	public void setFirstName(String first) {
		firstName = first;
	}

	// return first name
	public String getFirstName() {
		return firstName;
	}

	// set last name
	public void setLastName(String last) {
		lastName = last;
	}

	// return last name
	public String getLastName() {
		return lastName;
	}

	// set social security number
	public void setSocialSecurityNumber(String ssn) {
		socialSecurityNumber = ssn;
	}

	// return social security number
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	// return String representation of Employee object
	@Override
	public String toString() {
		return String.format("%s %s\nsocial security number: %s",
				getFirstName(), getLastName(), getSocialSecurityNumber());
	}

	// Note: We do not implement Payable method getPaymentAmount here so  
	// this class must be declared abstract to avoid a compilation error.
}