/*  COS 161 USM, FALL 2018
 * Professor: Phoulady
 * Project:   Program 3
 * Date:	  11/8/2018
 * Author:	  Omar Gonzaga 
 */
// Payable interface declaration.

public interface Payable {
	double getPaymentAmount(); // calculate payment; no implementation
} // end interface Payable